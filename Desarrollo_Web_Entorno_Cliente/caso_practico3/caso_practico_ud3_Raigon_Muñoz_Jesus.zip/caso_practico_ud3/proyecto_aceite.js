// Añadir evento de clic al botón para cambiar el tamaño de la ventana.
document.getElementById("resizeButton").addEventListener("click", function () {
  // Cambiar el tamaño de la ventana a 800x600 píxeles.
  window.resizeTo(800, 600);
  // Mostrar una alerta para confirmar el cambio de tamaño de la ventana.
  alert("Tamaño de la ventana cambiado a 800x600");
});

// Añadir evento de clic al botón para manejar el envío del formulario.
document.getElementById("submitButton").addEventListener("click", function () {

  // Obtener el valor ingresado en el campo de texto del producto
  const product = document.getElementById("product").value;

  if (product) {
    // Si el campo de texto no está vacío, generar un nuevo elemento de párrafo.
    const orderStatus = document.getElementById("orderStatus");
    const newOrder = document.createElement("p");
    // Establecer el contenido del nuevo párrafo con el producto ingresado.
    newOrder.textContent = `Su pedido de ${product} ha sido realizado correctamente.`;
    // Añadir el nuevo párrafo al div de estado del pedido.
    orderStatus.appendChild(newOrder);

    // Mostrar un mensaje de alerta confirmando que el pedido se ha realizado con éxito
    alert(`Su pedido de ${product} ha sido realizado con éxito.`);
  } else {
    // Si el campo de texto está vacío, mostrar un mensaje de alerta de error
    alert("Por favor, introduzca un producto.");
  }
});
